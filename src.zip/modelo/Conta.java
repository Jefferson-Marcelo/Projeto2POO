/**********************************
 * IFPB - Curso Superior de Tec. em Sist. para Internet
 * Programa��o Orientada a Objetos
 * Prof. Fausto Maranh�o Ayres
 **********************************/

package modelo;

public class Conta {

	
	public String getChavePIKS() {
		return "???";
	}
	
	/*
	 * metodos creditar(), debitar() e transferir()  // capitulos 3 e 4
	 * metodo debitar() nao deve permitir saldo negativo
	 * 
	 */
	
	
}
