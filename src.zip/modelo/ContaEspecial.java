/**********************************
 * IFPB - Curso Superior de Tec. em Sist. para Internet
 * Programa��o Orientada a Objetos
 * Prof. Fausto Maranh�o Ayres
 **********************************/

package modelo;

public class ContaEspecial extends Conta{
	//atributo limite
	
	/*
	 * sobrescrita de debitar()
	 */

	
}
